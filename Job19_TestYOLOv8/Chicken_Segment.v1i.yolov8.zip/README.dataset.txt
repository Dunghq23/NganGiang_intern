# Chicken_Segment > 2024-01-13 11:40am
https://universe.roboflow.com/dunghaquang/chicken_segment

Provided by a Roboflow user
License: CC BY 4.0

