# Chicken_Classification > Chicken_Classification
https://universe.roboflow.com/dunghaquang/chicken_classification

Provided by a Roboflow user
License: CC BY 4.0

